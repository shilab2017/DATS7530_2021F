#!/bin/bash

 printf "Script2 prints out: 1+1=%d.\n" `expr 1 + 1`