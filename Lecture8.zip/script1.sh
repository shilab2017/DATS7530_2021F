#!/bin/bash

echo "Script1 prints out: Hello World!"