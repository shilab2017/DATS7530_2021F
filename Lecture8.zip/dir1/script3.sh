#!/bin/bash

echo "Rscript3 prints out the full path of your current working directory:"
echo $PWD