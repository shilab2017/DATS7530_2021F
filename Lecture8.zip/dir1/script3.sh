#!/bin/bash

echo "Script3 prints out the full path of your current working directory:"
echo $PWD